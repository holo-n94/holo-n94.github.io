Please insert AMD ADL files adl_defines.h adl_sdk.h adl_structures.h here.

They can be found at
http://developer.amd.com/tools-and-sdks/graphics-development/display-library-adl-sdk/
